//
//  sideBarMenuViewController.swift
//  Mct
//
//  Created by maher deeb on 01/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class ProfileSideBarMenuViewController: UIViewController {
    @IBOutlet weak var btnMenuBar: UIBarButtonItem!
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var emailAdressLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var zipCodeLabel: UILabel!
    @IBOutlet weak var idNumberLabel: UILabel!
    @IBOutlet weak var license: UILabel!
    @IBOutlet weak var adressLabel: UILabel!
    
    var licenses : Int?
    var count  = 0
    var ref : DatabaseReference?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnMenuBar.target = revealViewController()
        btnMenuBar.action = #selector(SWRevealViewController.revealToggle(_:))
        ref = Database.database().reference()
        
//        firstNameLabel.text = User.shared.persons[CommonValues.count].personFirstName
//        lastNameLabel.text = User.shared.persons[CommonValues.count].personLastName
//        ageLabel.text = String(describing: User.shared.persons[CommonValues.count].personAge)
//        phoneNumberLabel.text = User.shared.persons[CommonValues.count].personPhoneNumber
//        emailAdressLabel.text = User.shared.persons[CommonValues.count].personEmailAdress
//        countryLabel.text = User.shared.persons[CommonValues.count].personCountry
//        cityLabel.text = User.shared.persons[CommonValues.count].personCity
//        zipCodeLabel.text = String(describing: User.shared.persons[CommonValues.count].personZipCode)
//        idNumberLabel.text = User.shared.persons[CommonValues.count].personIdNumber
//        carLicenseTLabel.text = User.shared.persons[CommonValues.count].personCarLicense
//        adressLabel.text = User.shared.persons[CommonValues.count].adress

        ref?.observe(.value, with: { snapshot in
            
                self.firstNameLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "name").value as? String
                self.lastNameLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "lastName").value as? String
                self.ageLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "age").value as? String
                self.phoneNumberLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "phoneNumber").value as? String
                self.emailAdressLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "emailAdress").value as? String
                self.countryLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "country").value as? String
                self.cityLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "city").value as? String
                self.zipCodeLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "zipCode").value as? String
                self.license.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "carLicense").value as? String
                self.adressLabel.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "street").value as? String
                self.idNumberLabel.text = String(CommonValues.id)
                CommonValues.carLicense = (snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "carLicense").value as? String)!
        })
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
