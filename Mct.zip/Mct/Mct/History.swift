//
//  History.swift
//  Mct
//
//  Created by maher deeb on 06/12/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

class History{
    
    var serviceName = ""
    var serviceCount = 0
}
