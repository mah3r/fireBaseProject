//
//  HistoryServiceSideBarMenuViewController.swift
//  Mct
//
//  Created by maher deeb on 07/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class HistoryServiceSideBarMenuViewController: UIViewController, UITableViewDataSource , UITableViewDelegate {

   @IBOutlet weak var btnMenuButton: UIBarButtonItem!
    @IBOutlet weak var history: UITableView!
    
    
    
    
    var count = 0
    let ref = Database.database().reference().child("history service").child(CommonValues.carLicense)

    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        
       
        
      
        
    }
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        count = 0
//
//        for x in 0..<User.shared.cars.count{
//            if User.shared.persons[CommonValues.id].personCarLicense == User.shared.cars[x].carLicenseNumber{
//                count += 1
//            }
//
//        return count
        
      
//        ref.observeEventType(.Value, withBlock: { (snapshot: FDataSnapshot!) in
//            count += snapshot.childrenCount
        
    
        return count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "historyService") as! HistoryTableViewCell
        
//        cell.label.text = User.shared.cars[indexPath.row].serviceHistory.rawValue
        
        
//        var service = historyServices()
//
//        service = historyServices[indexPath.row]
        
            cell.label.text = "maher"
        
            return cell
    }
    
    
   
    
    
}
