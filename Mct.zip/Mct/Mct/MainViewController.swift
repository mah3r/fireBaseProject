//
//  ViewController.swift
//  Mct
//
//  Created by maher deeb on 26/08/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class MainViewController: UIViewController {

    @IBOutlet weak var carLicense: UITextField!
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var sighInButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    
    

     var cars = ""
     var check : Bool = false
     var ref : DatabaseReference?
    
     override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
//        loadSomePersons()
        ref = Database.database().reference()
//        loadSomeCars()
        
    }
   
    

    
    
    @IBAction func signInTapped(_ sender: UIButton) {

//        for (Index,search) in User.shared.persons.enumerated(){
//
//            if  search.personCarLicense == carLicense.text {
//                if search.userName == userName.text{
//                    if search.password == password.text{
//                        CommonValues.count = Index
//                        check = true
//                    }
//                }
//            }
//       }
//        if check == true {
//            self.performSegue(withIdentifier: "segue1", sender: nil)
//        }else{
//            carLicense.text = "wrong inserted information"
//        }
        
        if let carlicense = Int(carLicense.text!) , userName.text != nil  , password.text != nil {
            
            CommonValues.id = carlicense
            ref?.observe(.value, with: { snapshot in
                
                Database.database().reference(withPath:
                    "person").child(String(CommonValues.id)).observe(.value, with: { (snapShot) in
                        if snapShot.exists() {
                            let tempUserName = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "userName").value as? String
                            let tempPassword = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: String(CommonValues.id)).childSnapshot(forPath: "password").value as? String
                            if tempUserName == self.userName.text{
                                if tempPassword == self.password.text{
                                    self.performSegue(withIdentifier: "segue1", sender: nil)
                                }else{
                                    self.alert(message: "Wrong Passowrd")
                                }
                            }else{
                                self.alert(message: "Wrong User Name")
                            }
                        }else{
                            self.alert(message: "Wrong Id")
                        }
                    })
            })
        
        }else{
            self.alert(message: "Please Fill All Fields")
        }
    }
    
    @IBAction func signUpTapped(_ sender: UIButton) {
         performSegue(withIdentifier: "segue2", sender: nil)
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//            segue.destination as? ProfileSideBarMenuViewController
//    }
    

//    func loadSomePersons(){
//        User.shared.persons.append(Person(firstName: "maher", lastName: "deeb", age: 27, phoneNumber: "0547907395", adress: "alnbi", email: "mahora5@hotmail.com", personCountry: "Israel", personCity: "haifa", personZipCode: 35664, idNumber: "302875430", carLicense: "3544460", userName: "mmaher", passWord: "mahoram"))
//        User.shared.persons.append(Person(firstName: "lara", lastName: "hob", age: 27, phoneNumber: "0547907395", adress: "alnbi", email: "mahora5@hotmail.com", personCountry: "Israel", personCity: "haifa", personZipCode: 35664, idNumber: "302875430", carLicense: "3511160", userName: "maher", passWord: "deeb"))
//        User.shared.persons.append(Person(firstName: "lorian", lastName: "jozef", age: 27, phoneNumber: "0547907395", adress: "alnbi", email: "mahora5@hotmail.com", personCountry: "Israel", personCity: "haifa", personZipCode: 35664, idNumber: "302875430", carLicense: "1234567", userName: "lorian", passWord: "123"))
//    }
//    func loadSomeCars(){
//        User.shared.cars.append(Car(model: "crv", manufacturer: "honda", vinNumber: "4332erm5675", manufaturingDate: "15/6/2017", immegrationDate: "1/1/18", engineCapacity: 1.8, hp: 142, licenseNumber: "3544460", carKiloMeters: 127324,service: .one))
//        User.shared.cars.append(Car(model: "crv", manufacturer: "honda", vinNumber: "4332erm5675", manufaturingDate: "15/6/2017", immegrationDate: "1/1/18", engineCapacity: 1.8, hp: 142, licenseNumber: "3544460", carKiloMeters: 127324,service: .two))
//        User.shared.cars.append(Car(model: "crv", manufacturer: "honda", vinNumber: "4332erm5675", manufaturingDate: "15/6/2017", immegrationDate: "1/1/18", engineCapacity: 1.8, hp: 142, licenseNumber: "3544460", carKiloMeters: 127324,service: .three))
//        User.shared.cars.append(Car(model: "hrv", manufacturer: "honda", vinNumber: "4332erm5675", manufaturingDate: "15/6/2017", immegrationDate: "1/1/18", engineCapacity: 1.8, hp: 142, licenseNumber: "1234567", carKiloMeters: 127324,service: .three))
//         User.shared.cars.append(Car(model: "jazz", manufacturer: "honda", vinNumber: "4332erm5675", manufaturingDate: "15/6/2017", immegrationDate: "1/1/18", engineCapacity: 1.8, hp: 142, licenseNumber: "3511160", carKiloMeters: 127324,service: .one))
//    }
    
}
extension UIViewController {
    
    func alert(message: String, title: String = "") {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
}
