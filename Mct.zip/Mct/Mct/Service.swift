//
//  Service.swift
//  Mct
//
//  Created by maher deeb on 21/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

enum BuildInServices : String {
    
    case one = " 15k "
    case two = " 30k "
    case three = " 45k "
    
    func caseService()-> String {
        switch self {
        case .one : return "oil,oil filter"
        case .two : return "oil,oil filter,air filter"
        case .three : return "oil,oil filter,pads oil"
        }
    
    }
    
}


class Service{
    
    var title : String = ""
    
    
    
}
