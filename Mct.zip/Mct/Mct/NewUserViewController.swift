//
//  NewUserViewController.swift
//  Mct
//
//  Created by maher deeb on 28/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import FirebaseDatabase

class NewUserViewController: UIViewController  {
  
    var ref : DatabaseReference?

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var phoneNumber: UITextField!
    @IBOutlet weak var country: UITextField!
    @IBOutlet weak var city: UITextField!
    @IBOutlet weak var streetAdress: UITextField!
    @IBOutlet weak var zipCode: UITextField!
    @IBOutlet weak var carLicense: UITextField!
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var passwordValidation: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var emailValidation: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference()
      
    }
    
   

    @IBAction func saveBtn(_ sender: UIBarButtonItem) {
        
       
        if passwordValidation.text == password.text{
            if emailValidation.text == email.text{
                
                
                self.ref?.child("person").child(id.text!).child("name").setValue(firstName.text)
                self.ref?.child("person").child(id.text!).child("lastName").setValue(lastName.text)
                self.ref?.child("person").child(id.text!).child("age").setValue(age.text)
                self.ref?.child("person").child(id.text!).child("phoneNumber").setValue(phoneNumber.text)
                self.ref?.child("person").child(id.text!).child("country").setValue(country.text)
                self.ref?.child("person").child(id.text!).child("city").setValue(city.text)
                self.ref?.child("person").child(id.text!).child("street").setValue(streetAdress.text)
                self.ref?.child("person").child(id.text!).child("zipCode").setValue(zipCode.text)
                self.ref?.child("person").child(id.text!).child("carLicense").setValue(carLicense.text)
                self.ref?.child("person").child(id.text!).child("userName").setValue(userName.text)
                self.ref?.child("person").child(id.text!).child("password").setValue(password.text)
                self.ref?.child("person").child(id.text!).child("emailAdress").setValue(email.text)

                dismiss(animated: true, completion: nil)
            }else{
                emailValidation.text = "Wrong email"
            }
            }else{
                passwordValidation.text = "wrong password"
            }
        }
    
    @IBAction func cancelBtn(_ sender: UIBarButtonItem) {
         dismiss(animated: true, completion: nil)
    }
    
    
    
    
}
