//
//  ServiceCentersTableViewCell.swift
//  Mct
//
//  Created by maher deeb on 24/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class ServiceCentersTableViewCell: UITableViewCell {

    
     @IBOutlet weak var label: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
