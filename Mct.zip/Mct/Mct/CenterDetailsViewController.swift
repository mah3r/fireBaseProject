//
//  CenterDetailsViewController.swift
//  Mct
//
//  Created by maher deeb on 27/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class CenterDetailsViewController: UIViewController {


    var name = ""
    var details = ""
    
    @IBOutlet weak var centerTitle: UILabel!
    @IBOutlet weak var centerDetails: UITextView!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        centerTitle.text = name
        centerDetails.text = details

        
        
    }

  
}
