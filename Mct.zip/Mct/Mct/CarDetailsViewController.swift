//
//  CarDetailsViewController.swift
//  Mct
//
//  Created by maher deeb on 26/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import FirebaseDatabase

class CarDetailsViewController: UIViewController {

    @IBOutlet weak var btnMenuButton: UIBarButtonItem!
    @IBOutlet weak var carManufacturer: UILabel!
    @IBOutlet weak var carVinNumber: UILabel!
    @IBOutlet weak var carManufacturingdate: UILabel!
    @IBOutlet weak var carEngineCapacity: UILabel!
    @IBOutlet weak var carHorsePower: UILabel!
    @IBOutlet weak var carKiloMeters: UILabel!
    @IBOutlet weak var carLicenseNumber: UILabel!
    @IBOutlet weak var carRoadImmegrationDate: UILabel!
    @IBOutlet weak var carModel: UILabel!
    
    var ref : DatabaseReference?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference()
        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        
//        for (index , x)in User.shared.cars.enumerated(){
//            if x.carLicenseNumber == User.shared.persons[CommonValues.count].personCarLicense{
        
         ref?.observe(.value, with: { snapshot in
            self.carModel.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "model").value as? String
            self.carManufacturer.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "manufacturer").value as? String
            self.carVinNumber.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "vinNumber").value as? String
            self.carManufacturingdate.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "manufacturingDate").value as? String
            self.carRoadImmegrationDate.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "immegrationDate").value as? String
            self.carEngineCapacity.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "engineCapacity").value as? String
            self.carHorsePower.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "hp").value as? String
            self.carLicenseNumber.text = CommonValues.carLicense
            self.carKiloMeters.text = snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: CommonValues.carLicense).childSnapshot(forPath: "carKilometers").value as? String
            
            })
        
        }
        
       
        
    }

   

