//
//  Car.swift
//  Mct
//
//  Created by maher deeb on 08/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

class Car{
    var carModel : String
    var carManufacturer : String
    var carVinNumber : String
    var carManufacturingdate : String
    var carRoadImmegrationDate : String
    var carEngineCapacity : Float
    var carHorsePower : Int
    var carLicenseNumber : String
    var carKiloMeters : Double
    var serviceHistory :BuildInServices
    
    init(model : String , manufacturer : String , vinNumber : String , manufaturingDate : String , immegrationDate : String , engineCapacity : Float , hp : Int , licenseNumber : String , carKiloMeters : Double ,service : BuildInServices ){
        
        self.carModel = model
        self.carManufacturer = manufacturer
        self.carVinNumber = vinNumber
        self.carManufacturingdate = manufaturingDate
        self.carRoadImmegrationDate = immegrationDate
        self.carEngineCapacity = engineCapacity
        self.carHorsePower = hp
        self.carLicenseNumber = licenseNumber
        self.carKiloMeters = carKiloMeters
        self.serviceHistory = service
    }
}

