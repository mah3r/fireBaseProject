//
//  DemoViewController.swift
//  Mct
//
//  Created by maher deeb on 06/11/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import FirebaseDatabase

class DemoViewController: UIViewController {

    @IBOutlet weak var one: UILabel!
    @IBOutlet weak var two: UILabel!
    @IBOutlet weak var three: UILabel!
    @IBOutlet weak var four: UILabel!
    
    var ref : DatabaseReference?
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
         ref = Database.database().reference()
        
        
       
        
        
        ref?.observe(.value, with: { snapshot in
            
            self.one.text = String(snapshot.childSnapshot(forPath: "cars").childSnapshot(forPath: "3544460").childSnapshot(forPath: "historyServices").childrenCount)
            self.two.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: "302875430").childSnapshot(forPath: "city").value as? String
            self.three.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: "302875430").childSnapshot(forPath: "age").value as? String
            self.four.text = snapshot.childSnapshot(forPath: "person").childSnapshot(forPath: "302875430").childSnapshot(forPath: "street").value as? String
        })
       
       
        
        

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
